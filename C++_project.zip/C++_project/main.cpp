#include <iostream>
#include <string>
#include <iomanip>
#include <cctype>
using namespace std;

// ----------------------------------------------------------- constants
const int ROWS = 8;                      // rows A..H
const int COLS = 10;                     // seats 1..10
const int MAX_BOOKINGS = ROWS * COLS;    // 80 seats in total
const int GST_PERCENT = 18;

// ----------------------------------------------------------- structures
struct Movie {
    string title;
    string language;
    string showTime;
    int durationMin;
};

struct Seat {                            // nested inside Booking
    int row;                             // 0-based
    int col;                             // 0-based
};

struct Customer {                        // nested inside Booking
    string name;
    string phone;
};

struct Booking {
    int id;
    Customer customer;                   // nested structure
    Seat seat;                           // nested structure
    int price;
};

// ----------------------------------------------------------- globals
Movie movie = {"Interstellar", "English", "07:30 PM", 169};
int bookingCount = 0;                    // number of valid records in bookings[]
int nextId = 1001;                       // next booking ID to be issued
bool inputEnded = false;                 // set when input stream is closed

// ===========================================================================
//                        STRING / INPUT HELPERS  (Module V)
// ===========================================================================
string toLower(string s) {               // string traversal, O(n)
    for (int i = 0; i < (int)s.length(); i++)
        s[i] = tolower(s[i]);
    return s;
}

string trim(string s) {                  // remove leading / trailing spaces
    int start = 0;
    int end = (int)s.length() - 1;
    while (start <= end && s[start] == ' ') start++;
    while (end >= start && s[end] == ' ') end--;
    return s.substr(start, end - start + 1);
}

bool isAllDigits(string s) {
    if (s.length() == 0) return false;
    for (int i = 0; i < (int)s.length(); i++)
        if (!isdigit(s[i])) return false;
    return true;
}

string readLine(string prompt) {
    string line;
    cout << prompt;
    if (!getline(cin, line)) {           // stream closed (Ctrl+D / end of file)
        inputEnded = true;
        return "";
    }
    return trim(line);
}

// Reads a number safely. Returns -1 when the input is not a valid number.
int readInt(string prompt) {
    string line = readLine(prompt);
    if (!isAllDigits(line) || line.length() > 6) return -1;
    int value = 0;
    for (int i = 0; i < (int)line.length(); i++)    // manual string -> int conversion
        value = value * 10 + (line[i] - '0');
    return value;
}

// ===========================================================================
//                            SEAT HELPERS
// ===========================================================================
// (row 2, col 4) -> "C5"
string seatLabel(int row, int col) {
    string s = "";
    s += (char)('A' + row);
    int n = col + 1;
    if (n >= 10) s += (char)('0' + n / 10);
    s += (char)('0' + n % 10);
    return s;
}

// "C5" or "c5" -> row*COLS + col.  Returns -1 for an invalid seat.
int parseSeat(string s) {
    s = trim(s);
    if (s.length() < 2 || s.length() > 3) return -1;
    char letter = toupper(s[0]);
    if (letter < 'A' || letter >= 'A' + ROWS) return -1;
    string digits = s.substr(1);
    if (!isAllDigits(digits)) return -1;
    int n = 0;
    for (int i = 0; i < (int)digits.length(); i++)
        n = n * 10 + (digits[i] - '0');
    if (n < 1 || n > COLS) return -1;
    return (letter - 'A') * COLS + (n - 1);
}

// ===========================================================================
//                               PRICING
// ===========================================================================
int seatPrice(int row) {                 // price depends on row tier, O(1)
    if (row <= 2) return 150;            // A-C : Standard
    if (row <= 5) return 250;            // D-F : Premium
    return 400;                          // G-H : Recliner
}

string seatTier(int row) {
    if (row <= 2) return "Standard";
    if (row <= 5) return "Premium";
    return "Recliner";
}

// ===========================================================================
//                       VALIDATION  (invalid input handling)
// ===========================================================================
bool validName(string name) {
    if (name.length() == 0 || name.length() > 25) return false;
    bool hasLetter = false;
    for (int i = 0; i < (int)name.length(); i++) {
        if (isalpha(name[i])) hasLetter = true;
        else if (name[i] != ' ' && name[i] != '.') return false;
    }
    return hasLetter;
}

bool validPhone(string phone) {
    return phone.length() == 10 && isAllDigits(phone);
}

// ===========================================================================
//                    SEARCHING  (linear search, Module III)
// ===========================================================================
// Returns index of booking with given ID, or -1.            Time: O(n)
int findBookingById(Booking b[], int count, int id) {
    for (int i = 0; i < count; i++)
        if (b[i].id == id) return i;
    return -1;
}

// ===========================================================================
//                               DISPLAY
// ===========================================================================
void displayMovie() {
    cout << "\n==============================================\n";
    cout << "  NOW SHOWING : " << movie.title << "\n";
    cout << "  Language    : " << movie.language << "\n";
    cout << "  Show time   : " << movie.showTime << "\n";
    cout << "  Duration    : " << movie.durationMin << " min\n";
    cout << "==============================================\n";
}

// Passing a 2D array to a function: column size must be given.   Time: O(ROWS*COLS)
void displaySeatLayout(int seats[][COLS]) {
    displayMovie();
    cout << "\n              [ S C R E E N ]\n\n      ";
    for (int c = 0; c < COLS; c++) cout << setw(3) << (c + 1);
    cout << "\n";
    for (int r = 0; r < ROWS; r++) {
        cout << "  " << (char)('A' + r) << "   ";
        for (int c = 0; c < COLS; c++) {
            if (seats[r][c] == 0) cout << setw(3) << "O";
            else                  cout << setw(3) << "X";
        }
        cout << "    " << seatTier(r) << " Rs." << seatPrice(r) << "\n";
    }
    cout << "\n  O = Available    X = Booked\n";
}

void displayBookedAndAvailable(int seats[][COLS]) {
    int booked = 0;
    for (int r = 0; r < ROWS; r++)
        for (int c = 0; c < COLS; c++)
            if (seats[r][c] != 0) booked++;

    cout << "\n--- Booked Seats (" << booked << ") ---\n";
    if (booked == 0) {
        cout << "  (none)\n";
    } else {
        for (int r = 0; r < ROWS; r++)
            for (int c = 0; c < COLS; c++)
                if (seats[r][c] != 0) cout << seatLabel(r, c) << " ";
        cout << "\n";
    }

    cout << "\n--- Available Seats (" << MAX_BOOKINGS - booked << ") ---\n";
    if (booked == MAX_BOOKINGS) {
        cout << "  (HOUSE FULL)\n";
    } else {
        for (int r = 0; r < ROWS; r++) {
            cout << "  Row " << (char)('A' + r) << ": ";
            bool any = false;
            for (int c = 0; c < COLS; c++) {
                if (seats[r][c] == 0) {
                    cout << seatLabel(r, c) << " ";
                    any = true;
                }
            }
            if (!any) cout << "(full)";
            cout << "\n";
        }
    }
}

void printBookingHeader() {
    cout << "\n  " << left << setw(7) << "ID" << setw(22) << "Customer"
         << setw(13) << "Phone" << setw(6) << "Seat" << setw(10) << "Tier"
         << "Price\n" << right;
    cout << "  " << string(65, '-') << "\n";
}

void printBooking(Booking b) {           // structure passed to a function
    cout << "  " << left << setw(7) << b.id << setw(22) << b.customer.name
         << setw(13) << b.customer.phone
         << setw(6) << seatLabel(b.seat.row, b.seat.col)
         << setw(10) << seatTier(b.seat.row)
         << "Rs." << b.price << "\n" << right;
}

void displayAllBookings(Booking b[], int count) {
    if (count == 0) {
        cout << "\nNo bookings yet.\n";
        return;
    }
    printBookingHeader();
    int total = 0;
    for (int i = 0; i < count; i++) {
        printBooking(b[i]);
        total += b[i].price;
    }
    cout << "  " << string(65, '-') << "\n";
    cout << "  Total bookings: " << count << "     Revenue: Rs." << total << "\n";
}

// ===========================================================================
//                              OPERATIONS
// ===========================================================================

// ---- 1. BOOK A SEAT ------------------------------------------------------
// Seat check is O(1) (direct index in 2D array); insert at end of array is O(1).
void bookSeat(int seats[][COLS], Booking b[]) {
    if (bookingCount >= MAX_BOOKINGS) {                     // unavailable resource
        cout << "\nSorry, HOUSE FULL. No seats available.\n";
        return;
    }

    string name = readLine("Customer name: ");
    if (!validName(name)) {
        cout << "Invalid name. Use letters, spaces and '.' only (max 25 characters).\n";
        return;
    }
    string phone = readLine("Phone number (10 digits): ");
    if (!validPhone(phone)) {
        cout << "Invalid phone number. It must contain exactly 10 digits.\n";
        return;
    }

    // Duplicate entry check: same name already has a booking?   O(n)
    int existing = 0;
    for (int i = 0; i < bookingCount; i++)
        if (toLower(b[i].customer.name) == toLower(name)) existing++;
    if (existing > 0) {
        cout << "Note: '" << name << "' already has " << existing << " booking(s).\n";
        string ans = readLine("Book an additional seat for the same name? (y/n): ");
        if (ans != "y" && ans != "Y") {
            cout << "Booking cancelled.\n";
            return;
        }
    }

    displaySeatLayout(seats);
    int code = parseSeat(readLine("\nEnter seat to book (e.g. C5): "));
    if (code == -1) {
        cout << "Invalid seat. Rows are A-" << (char)('A' + ROWS - 1)
             << " and seat numbers are 1-" << COLS << ".\n";
        return;
    }
    int r = code / COLS;
    int c = code % COLS;

    if (seats[r][c] != 0) {                                 // already occupied
        cout << "Seat " << seatLabel(r, c) << " is already booked. Please choose another seat.\n";
        return;
    }

    Booking nb;
    nb.id = nextId++;
    nb.customer.name = name;
    nb.customer.phone = phone;
    nb.seat.row = r;
    nb.seat.col = c;
    nb.price = seatPrice(r);

    b[bookingCount] = nb;                                   // insert at end
    bookingCount++;
    seats[r][c] = nb.id;                                    // mark seat as booked

    cout << "\nBooking confirmed!";
    printBookingHeader();
    printBooking(nb);
}

// ---- 2. CANCEL A BOOKING -------------------------------------------------
// Linear search O(n) + shifting elements left O(n).
void cancelBooking(int seats[][COLS], Booking b[]) {
    if (bookingCount == 0) {
        cout << "\nNo bookings to cancel.\n";
        return;
    }
    displayAllBookings(b, bookingCount);

    int id = readInt("\nEnter Booking ID to cancel: ");
    if (id == -1) {
        cout << "Invalid input. Booking ID must be a number.\n";
        return;
    }
    int idx = findBookingById(b, bookingCount, id);
    if (idx == -1) {
        cout << "No booking found with ID " << id << ".\n";
        return;
    }

    string ans = readLine("Cancel booking of " + b[idx].customer.name + " for seat "
                          + seatLabel(b[idx].seat.row, b[idx].seat.col) + "? (y/n): ");
    if (ans != "y" && ans != "Y") {
        cout << "Cancellation aborted.\n";
        return;
    }

    seats[b[idx].seat.row][b[idx].seat.col] = 0;            // free the seat
    for (int i = idx; i < bookingCount - 1; i++)            // delete from array: shift left
        b[i] = b[i + 1];
    bookingCount--;
    cout << "Booking " << id << " cancelled. The seat is available again.\n";
}

// ---- 3. SEARCH BY CUSTOMER NAME -----------------------------------------
// Linear search over the array; case-insensitive substring (pattern) match.
// Time: O(n * m) where n = records, m = name length.
void searchByName(Booking b[], int count) {
    if (count == 0) {
        cout << "\nNo bookings to search.\n";
        return;
    }
    string key = readLine("Enter customer name (or part of it): ");
    if (key.length() == 0) {
        cout << "Search text cannot be empty.\n";
        return;
    }
    string k = toLower(key);

    int found = 0;
    for (int i = 0; i < count; i++) {
        string name = toLower(b[i].customer.name);
        if (name.find(k) != string::npos) {
            if (found == 0) printBookingHeader();
            printBooking(b[i]);
            found++;
        }
    }
    if (found == 0) cout << "No booking found for '" << key << "'.\n";
    else            cout << "\n" << found << " record(s) found.\n";
}

// ---- 4. UPDATE: CHANGE SEAT ---------------------------------------------
void updateBooking(int seats[][COLS], Booking b[]) {
    if (bookingCount == 0) {
        cout << "\nNo bookings to update.\n";
        return;
    }
    int id = readInt("Enter Booking ID to change seat: ");
    if (id == -1) {
        cout << "Invalid input. Booking ID must be a number.\n";
        return;
    }
    int idx = findBookingById(b, bookingCount, id);
    if (idx == -1) {
        cout << "No booking found with ID " << id << ".\n";
        return;
    }

    displaySeatLayout(seats);
    cout << "\nCurrent seat: " << seatLabel(b[idx].seat.row, b[idx].seat.col) << "\n";
    int code = parseSeat(readLine("Enter new seat (e.g. D4): "));
    if (code == -1) {
        cout << "Invalid seat.\n";
        return;
    }
    int r = code / COLS;
    int c = code % COLS;
    if (seats[r][c] != 0) {
        cout << "Seat " << seatLabel(r, c) << " is already booked.\n";
        return;
    }

    seats[b[idx].seat.row][b[idx].seat.col] = 0;            // free old seat
    b[idx].seat.row = r;
    b[idx].seat.col = c;
    b[idx].price = seatPrice(r);                            // recalculate price
    seats[r][c] = id;                                       // occupy new seat
    cout << "Seat changed to " << seatLabel(r, c) << ". New price: Rs." << b[idx].price << "\n";
}

// ---- 5. TICKET PRICE CALCULATOR -----------------------------------------
void calculatePrice() {
    int code = parseSeat(readLine("Enter any seat to check its price (e.g. B3): "));
    if (code == -1) {
        cout << "Invalid seat.\n";
        return;
    }
    int r = code / COLS;
    int n = readInt("Number of tickets (1-10): ");
    if (n < 1 || n > 10) {
        cout << "Number of tickets must be between 1 and 10.\n";
        return;
    }
    int base = seatPrice(r) * n;
    int gst = base * GST_PERCENT / 100;
    cout << "\n  Tier           : " << seatTier(r)
         << "\n  Price / ticket : Rs." << seatPrice(r)
         << "\n  Subtotal       : Rs." << base
         << "\n  GST (" << GST_PERCENT << "%)      : Rs." << gst
         << "\n  Total          : Rs." << base + gst << "\n";
}

// ---- 6. REPORT: occupancy per row and revenue ---------------------------
// Traverses the whole 2D array once.                      Time: O(ROWS*COLS)
void occupancyReport(int seats[][COLS], Booking b[], int count) {
    if (count == 0) {
        cout << "\nNo bookings to report.\n";
        return;
    }
    cout << "\n--- Occupancy Report ---\n";
    cout << "  Row  Tier       Booked/Total\n";
    cout << "  " << string(32, '-') << "\n";
    for (int r = 0; r < ROWS; r++) {
        int booked = 0;
        for (int c = 0; c < COLS; c++)
            if (seats[r][c] != 0) booked++;
        cout << "  " << (char)('A' + r) << "    " << left << setw(10) << seatTier(r)
             << right << setw(3) << booked << " / " << COLS << "\n";
    }
    int revenue = 0;
    for (int i = 0; i < count; i++) revenue += b[i].price;
    int percent = count * 100 / MAX_BOOKINGS;               // integer division
    cout << "  " << string(32, '-') << "\n";
    cout << "  Seats booked : " << count << " / " << MAX_BOOKINGS
         << "  (" << percent << "% occupancy)\n";
    cout << "  Revenue      : Rs." << revenue << "\n";
}

// ===========================================================================
//                                MENUS
// ===========================================================================
void displayMenu(int seats[][COLS], Booking b[]) {
    cout << "\n--- DISPLAY ---\n"
         << " 1. Movie details & seat layout\n"
         << " 2. Booked and available seats\n"
         << " 3. All booking records\n"
         << " 4. Ticket price calculator\n";
    int ch = readInt("Choice: ");
    switch (ch) {
        case 1: displaySeatLayout(seats); break;
        case 2: displayBookedAndAvailable(seats); break;
        case 3: displayAllBookings(b, bookingCount); break;
        case 4: calculatePrice(); break;
        default: cout << "Invalid option.\n";
    }
}

void mainMenu() {
    cout << "\n=========== MOVIE TICKET BOOKING ===========\n"
         << " 1. Book a seat\n"
         << " 2. Display (layout / seats / records / price)\n"
         << " 3. Search booking by customer name\n"
         << " 4. Update booking (change seat)\n"
         << " 5. Cancel booking\n"
         << " 6. Report (occupancy and revenue)\n"
         << " 7. Exit\n"
         << "============================================\n";
}

int main() {
    int seats[ROWS][COLS];                       // 2D array: 0 = free, else booking ID
    Booking bookings[MAX_BOOKINGS];              // array of structures

    for (int r = 0; r < ROWS; r++)               // initialise all seats as available
        for (int c = 0; c < COLS; c++)
            seats[r][c] = 0;

    int choice = 0;
    do {
        mainMenu();
        choice = readInt("Enter choice (1-7): ");
        if (inputEnded) break;
        switch (choice) {
            case 1: bookSeat(seats, bookings); break;
            case 2: displayMenu(seats, bookings); break;
            case 3: searchByName(bookings, bookingCount); break;
            case 4: updateBooking(seats, bookings); break;
            case 5: cancelBooking(seats, bookings); break;
            case 6: occupancyReport(seats, bookings, bookingCount); break;
            case 7: cout << "\nThank you! Enjoy the movie.\n"; break;
            default: cout << "Invalid choice! Please enter a number from 1 to 7.\n";
        }
    } while (choice != 7 && !inputEnded);

    return 0;
}